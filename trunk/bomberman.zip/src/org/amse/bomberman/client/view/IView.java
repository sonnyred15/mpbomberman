package org.amse.bomberman.client.view;
/**
 *
 * @author michail korovkin
 */
public interface IView {
    public void update();
}
