package org.amse.bomberman.client;
import org.amse.bomberman.client.view.StartJFrame;

/**
 *
 * @author michail korovkin
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        StartJFrame sjf = new StartJFrame();
    }
}
